import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './tests',

  retries: 1,

  use: {
    headless: false,
    viewport: { width: 1280, height: 720 },

    trace: 'on',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
  },

  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
  ],
});
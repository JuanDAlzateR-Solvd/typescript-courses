import { defineConfig, devices } from '@playwright/test';

const ENV = process.env.TEST_ENV || 'dev';

export default defineConfig({
  testDir: './tests',

  use: {
    baseURL:
      ENV === 'staging'
        ? 'https://demo.playwright.dev/todomvc'
        : 'https://demo.playwright.dev/todomvc',

    headless: false,
  },

  metadata: {
    environment: ENV,
    build: 'v1.0-demo',
  },

  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
  ],
});
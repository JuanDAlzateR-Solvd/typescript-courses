import { defineConfig, devices } from '@playwright/test';

const ENV = process.env.TEST_ENV || 'staging';

const environmentSettings = {
  staging: {
    baseURL: 'https://demo.playwright.dev',
    retries: 1,
    headless: false,
    metadata: {
      environment: 'staging',
      build: 'staging-build-v2',
      target: 'pre-release validation',
      releaseChannel: 'candidate',
      configuredRetries: 1,
    },
  },
  production: {
    baseURL: 'https://demo.playwright.dev',
    retries: 0,
    headless: false,
    metadata: {
      environment: 'production',
      build: 'production-build-v2',
      target: 'live validation',
      releaseChannel: 'stable',
      configuredRetries: 0,
    },
  },
}[ENV as 'staging' | 'production'];

export default defineConfig({
  testDir: './tests',

  timeout: 30_000,

  expect: {
    timeout: 5_000,
  },

  retries: environmentSettings.retries,

  use: {
    baseURL: environmentSettings.baseURL,
    headless: environmentSettings.headless,
    viewport: { width: 1280, height: 720 },
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
  },

  metadata: environmentSettings.metadata,

  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
  ],
});